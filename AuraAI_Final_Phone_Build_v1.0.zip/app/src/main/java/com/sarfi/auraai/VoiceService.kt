package com.sarfi.auraai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder

class VoiceService : Service() {
    private val channelId = "auraai_voice"

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                channelId,
                "AuraAI Voice",
                NotificationManager.IMPORTANCE_LOW
            )
        )

        val notification: Notification =
            Notification.Builder(this, channelId)
                .setContentTitle("AuraAI")
                .setContentText("Voice service is running")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()

        startForeground(100, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
