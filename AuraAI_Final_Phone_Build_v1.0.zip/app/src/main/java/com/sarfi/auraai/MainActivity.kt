package com.sarfi.auraai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val micRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val status = TextView(this).apply {
            text = "AuraAI\nOwner-controlled assistant\n\nVoice service is available after microphone permission."
            textSize = 20f
            setPadding(40, 60, 40, 30)
        }

        val start = Button(this).apply {
            text = "Start Voice Service"
            setOnClickListener { startVoiceService() }
        }

        val stop = Button(this).apply {
            text = "Stop Voice Service"
            setOnClickListener {
                stopService(Intent(this@MainActivity, VoiceService::class.java))
                status.text = "AuraAI\nVoice service stopped."
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 30, 30, 30)
            addView(status)
            addView(start)
            addView(stop)
        }
        setContentView(layout)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                micRequest
            )
        }
    }

    private fun startVoiceService() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
            return
        }
        ContextCompat.startForegroundService(
            this,
            Intent(this, VoiceService::class.java)
        )
    }
}
