# AuraAI — Phone Build v1.0

This repository is a properly structured Android Studio project.

## Current included foundation

- Android application module
- Kotlin + Android Gradle Plugin configuration
- Microphone permission
- Foreground voice-service foundation
- Start/stop voice service UI
- Internet permission for future research backend
- Clean separation between app module and root Gradle files
- GitHub Actions workflow for cloud debug APK builds

## Important

This is source code, not a precompiled APK.

The larger features discussed for AuraAI (LLM provider integrations, web research, screen context, personal memory, market data, business ledger, etc.) require their actual backend/API implementations and testing. They are not represented as magically completed just by this starter build.

Never put API keys, passwords, PINs, broker credentials, or personal records directly into the repository.

## Build

From a machine with Android SDK + JDK 17 + Gradle:

    gradle :app:assembleDebug

The APK will normally be:

    app/build/outputs/apk/debug/app-debug.apk
